# Amit Ghadage — Software Developer Portfolio

A recruiter-focused, responsive portfolio website built with a Charcoal + Emerald Green color palette, highlighting Java 17, Spring Boot, Microservices, and Angular expertise.

## Quick 2-Minute Deployment (GitHub Pages)

1. Create a repository named `portfolio` (or `Grossy18.github.io`) on your GitHub account (`Grossy18`).
2. Upload `index.html` and `Amit_Ghadage_Resume.pdf` to the root of the repository.
3. In GitHub, go to **Settings > Pages**.
4. Under **Build and deployment > Branch**, select `main` and `/ (root)`, then click **Save**.
5. Your portfolio will be live at `https://Grossy18.github.io/portfolio` within 60 seconds with free HTTPS/SSL!

## Alternative: Vercel / Netlify
1. Go to [vercel.com](https://vercel.com) and click **Add New Project**.
2. Select your repository and click **Deploy**.
3. Optionally add your custom domain (e.g. `amitghadage.dev`).
